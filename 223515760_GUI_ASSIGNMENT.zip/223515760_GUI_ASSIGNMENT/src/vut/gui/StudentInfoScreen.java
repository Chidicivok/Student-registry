// Chigbu, CCI - 223515760
package vut.gui;

import javax.swing.*;  //  for the jframe componets
import java.awt.Event.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import vut.data.StudentClass;

public class StudentInfoScreen extends JFrame {

     private ArrayList<StudentClass> arrStudenInfo = new ArrayList<>();

     // create objects for labels labels on form
     JLabel lblStudentNumber = new JLabel("Student Number :   ");
     JLabel lblStudentName = new JLabel("Student Name :   ");
     JLabel lblGender = new JLabel("Gender :   ");
     JLabel lblSubjectCode = new JLabel("Subject Code :   ");
     JLabel lblStudentMarks = new JLabel("Student Marks :   ");

     // create objects for the inputs   - Order of creation not important
     // text fields
     JTextField txtStudentNumber = new JTextField();
     JTextField txtStudentName = new JTextField();
     JTextField txtStudentMarks = new JTextField();

     // radio buttons
     JRadioButton rbnMale = new JRadioButton("MALE");
     JRadioButton rbnFemale = new JRadioButton("FEMALE");
     
     // handle radio button


     //COMBO BOX
     JComboBox<String> cmbSubjectCode = new JComboBox<>();

     //buttons
     JButton btnAddStudent = new JButton("ADD STUDENT");
     JButton btnClear = new JButton("CLEAR");
     JButton btnClose = new JButton("CLOSE");

//     // text area
//     JTextArea taDisplay = new JTextArea();
     // create constructor for the form to bring the componenets together
     public StudentInfoScreen(ArrayList<StudentClass> arrStudenInfo) {

          this.arrStudenInfo =arrStudenInfo;
          
          // enter values into combo box for subject code
          cmbSubjectCode.addItem("Select Subject Code");
          cmbSubjectCode.addItem("AIUBX3B");
          cmbSubjectCode.addItem("AIWEX3A");
          cmbSubjectCode.addItem("ASDSX3A");
          cmbSubjectCode.addItem("ASDSY3A");

          // create object for your panel
          JPanel panMain = new JPanel();

          // set the jpanel layout to null to allow for manual posiitioning
          panMain.setLayout(null);

          // add the created components onto the panel
          panMain.add(lblStudentNumber);
          panMain.add(txtStudentNumber);
          panMain.add(lblStudentName);
          panMain.add(txtStudentName);
          panMain.add(lblGender);
          panMain.add(rbnMale);
          panMain.add(rbnFemale);
          panMain.add(lblSubjectCode);
          panMain.add(cmbSubjectCode);
          panMain.add(lblStudentMarks);
          panMain.add(txtStudentMarks);
          panMain.add(btnAddStudent);
          panMain.add(btnClear);
          panMain.add(btnClose);

          // set bounds to position each component
          // for inputs
          lblStudentNumber.setBounds(20, 20, 150, 25);
          txtStudentNumber.setBounds(190, 20, 200, 25);

          lblStudentName.setBounds(20, 60, 150, 25);
          txtStudentName.setBounds(190, 60, 200, 25);

          lblGender.setBounds(20, 100, 150, 25);
          rbnMale.setBounds(190, 100, 70, 25);
          rbnFemale.setBounds(270, 100, 80, 25);

          lblSubjectCode.setBounds(20, 140, 150, 25);
          cmbSubjectCode.setBounds(190, 140, 200, 25);

          lblStudentMarks.setBounds(20, 180, 150, 25);
          txtStudentMarks.setBounds(190, 180, 200, 25);

          // buttons
          btnAddStudent.setBounds(20, 230, 130, 30);
          btnClear.setBounds(300, 230, 100, 30);
          btnClose.setBounds(160, 230, 130, 30);

//          //display
//          taDisplay.setBounds(20, 280, 380, 150);
          // set the contents of the panel to the jframe  -- can use add(panMain)
          setContentPane(panMain);

//          // register the action performed event for view
//          btnViewStudentInfo.addActionListener(new btnViewAllEvent());

          // register event for clear
          btnClear.addActionListener(new btnClearEvent());

          // register for add
          btnAddStudent.addActionListener(new btnAddStudentEvent());
          
          // register for close
          btnClose.addActionListener(new btnCloseEvent());
          
          // register radiobuttons
          rbnMale.addActionListener( new rbnMaleEvent());
          rbnFemale.addActionListener(new rbnFemaleEvent());
     }

     // inner class for close button
     private class btnCloseEvent implements ActionListener {

          @Override
          public void actionPerformed(ActionEvent e) {
             dispose();
          }
          
     }
     
     
//     // an inner class to handle events
//     private class btnViewAllEvent implements ActionListener {
//
//          @Override
//          public void actionPerformed(ActionEvent e) {
//
//               ViewScreen objViewScreen = new ViewScreen(arrStudenInfo);
//
//               objViewScreen.setTitle("View Screen By Chidi");
//
//               objViewScreen.setSize(450, 550);
//
//               objViewScreen.setVisible(true);
//
//               objViewScreen.viewAll(arrStudenInfo);
//          }
//
//     }

     // event for clear buttons
     private class btnClearEvent implements ActionListener {

          @Override
          public void actionPerformed(ActionEvent e) {

               txtStudentMarks.setText("");
               txtStudentName.setText("");
               txtStudentNumber.setText("");
               cmbSubjectCode.setSelectedIndex(0);
               rbnFemale.setSelected(false);
               rbnMale.setSelected(false);
//               taDisplay.setText("");
          }

     }
     
     // create method of studentclass datatype 
     public StudentClass collectInputs() {
          
           // attributes
                    String stNo, name, gender, subjCode;
                    int marks;

                    for (int i = 0; i < arrStudenInfo.size(); i++) {
                         
                         if (arrStudenInfo.get(i).getStudentNumber().equals(txtStudentNumber.getText().trim())) {
                              throw new IllegalArgumentException("Duplicate student number");
                         }
                    }
                    
                    
                    //get the inputs
                    stNo = txtStudentNumber.getText().trim();
                    name = txtStudentName.getText();
                    
                    if(cmbSubjectCode.getSelectedIndex() == 0) {
                         throw new IllegalArgumentException("Select a subject code");
                    }
                    subjCode = cmbSubjectCode.getSelectedItem().toString();
                    
                    for (int i = 0; i < txtStudentMarks.getText().length(); i++) {
                         if (!Character.isDigit(txtStudentMarks.getText().charAt(i))) {
                              throw new IllegalArgumentException("Student marks  must be numerical");
                         }
                    }
                    
                    
                    marks = Integer.parseInt(txtStudentMarks.getText());

                    // control gender radio buttons
                    if (rbnMale.isSelected()) {
                         gender = rbnMale.getText();

                    } else if (rbnFemale.isSelected()) {
                         gender = rbnFemale.getText();
                    } else {
                         throw new IllegalArgumentException("Select a gender");
                    }

                    // create object of student class to store values
                    StudentClass objStudentClass = new StudentClass(stNo, name, gender, subjCode, marks);

          
          
          return objStudentClass;
     }
     
     private  class rbnMaleEvent implements ActionListener {

          @Override
          public void actionPerformed(ActionEvent e) {
            rbnFemale.setSelected(false);
          }
          
     }
     
      private  class rbnFemaleEvent implements ActionListener {

          @Override
          public void actionPerformed(ActionEvent e) {
            rbnMale.setSelected(false);
          }
          
     }
     
     

     // event for add students
     private class btnAddStudentEvent implements ActionListener {

          @Override
          public void actionPerformed(ActionEvent e) {

               try {
                   
                    StudentClass objStudentClass = collectInputs();
                    
                    // add object to array
                    arrStudenInfo.add(objStudentClass);

                    // info message if succesful
                    JOptionPane.showMessageDialog(rootPane, "Student Added", "Information", JOptionPane.INFORMATION_MESSAGE);

                    //call clear button
                    btnClear.doClick();

               } catch (Exception ev) {
                    JOptionPane.showMessageDialog(rootPane, ev.getMessage(), "", JOptionPane.ERROR_MESSAGE);
               }

          }

     }
}

     /**
      * @param args the command line arguments
      */
//     public static void main(String[] args) {
//
//          StudentClass objStudentClass = null;
//          
//          ArrayList<StudentClass> objarr = null;
//          
//          // create object for the class
//          StudentInfoScreen objfrmStudentInfoScreen = new StudentInfoScreen(objarr);
//
//          // add title to your form
//          objfrmStudentInfoScreen.setTitle("Student Screen By Chidi-223515760");
//
//          // make form visible
//          objfrmStudentInfoScreen.setVisible(true);
//
//          // set the size of the frame
//          objfrmStudentInfoScreen.setSize(450, 550);
//
//     }
//
//}
