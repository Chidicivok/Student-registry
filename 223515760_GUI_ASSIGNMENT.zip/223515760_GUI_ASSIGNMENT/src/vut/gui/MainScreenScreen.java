//Chigbu CCI - 223515760
package vut.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.*;
import vut.data.StudentClass;

public class MainScreenScreen extends JFrame {

     //Declare menu 
     JMenu mnuFile, mnuStudent;

     //declaring menu items
     JMenuItem mnuSearch, mnuHighest, mnuCount, mnuExit;
     JMenuItem mnuAdd, mnuDisplay;
     
     

     // create array of student class type
     private ArrayList<StudentClass> arrStudentList;

     // constructor for main menu
     public MainScreenScreen() {

          // object of array to be created on initialization
          arrStudentList = new ArrayList<>();

          //name menus
          mnuFile = new JMenu("FILE");
          mnuStudent = new JMenu("STUDENT");

          // name menu items
          mnuSearch = new JMenuItem("Search Student Number");
          mnuHighest = new JMenuItem("Student with Highest Mark");
          mnuCount = new JMenuItem("Count by Subject Code");
          mnuExit = new JMenuItem("Exit");

          mnuAdd = new JMenuItem("Add New Student");
          mnuDisplay = new JMenuItem("Display All Students");

          // fix menu items to menus
          mnuFile.add(mnuSearch);
          mnuFile.add(mnuHighest);
          mnuFile.add(mnuCount);
          mnuFile.add(mnuExit);

          mnuStudent.add(mnuAdd);
          mnuStudent.add(mnuDisplay);

          // create menu bar
          JMenuBar mbrMainMenu = new JMenuBar();

          // add menus onto the menu bar
          mbrMainMenu.add(mnuFile);
          mbrMainMenu.add(mnuStudent);

          // call setmenu bar method to make menu bar visible
          setJMenuBar(mbrMainMenu);

          // register events
          mnuAdd.addActionListener(new mnuAddStudentEvent());
          mnuDisplay.addActionListener(new mnuViewAllEvent());

          mnuSearch.addActionListener(new mnuSearchEvent());
          mnuHighest.addActionListener(new mnuHighestMarkEvent());
          mnuCount.addActionListener(new mnuCountEvent());
          mnuExit.addActionListener(new mnuExitEvent());

     }

     //inner class for menu items
     private class mnuAddStudentEvent implements ActionListener {

          @Override
          public void actionPerformed(ActionEvent e) {

               StudentInfoScreen objFrStudentInfoScreen = new StudentInfoScreen(arrStudentList);
               objFrStudentInfoScreen.setVisible(true);
               objFrStudentInfoScreen.setSize(450, 550);
               objFrStudentInfoScreen.setTitle("Student Info Screen By Chigbu CCI");
               objFrStudentInfoScreen.setResizable(false);
          }

     }

     private class mnuViewAllEvent implements ActionListener {

          @Override
          public void actionPerformed(ActionEvent e) {

               ViewScreen objFrViewScreen = new ViewScreen(arrStudentList);
               objFrViewScreen.setVisible(true);
               objFrViewScreen.setSize(450, 550);
               objFrViewScreen.setTitle("Student View Screen By Chigbu CCI");
               objFrViewScreen.setResizable(false);

          }

     }

     private class mnuSearchEvent implements ActionListener {

          @Override
          public void actionPerformed(ActionEvent e) {

               //create string to store user input from an inputbox
               String inputStudentNumber = JOptionPane.showInputDialog(this, "Enter student number  :   ");

               // boolean variable to handle if i found the student number or not
               boolean isFound = false;

               //create similar array to store if found
               ArrayList<StudentClass> arrSearch = new ArrayList<>();

               // for loop to check each ccontent of the assstudent list
               for (StudentClass objStudentClass : arrStudentList) {

                    //compare the user input with array student numbers
                    if (objStudentClass.getStudentNumber().equals(inputStudentNumber)) {
                         arrSearch.add(objStudentClass);
                         isFound = true;
                         break;
                    }

               }

               // if found call the display scrren
               if (isFound) {
                    ViewScreen objFrViewScreen = new ViewScreen(arrSearch);
                    objFrViewScreen.setVisible(true);
                    objFrViewScreen.setSize(450, 550);
                    objFrViewScreen.setTitle("Student Search Screen By Chigbu CCI");
                    objFrViewScreen.setResizable(false);

               } else {
                    JOptionPane.showMessageDialog(rootPane, "Student number not found.", "Search Result", JOptionPane.ERROR_MESSAGE);
               }

          }

     }

     private class mnuHighestMarkEvent implements ActionListener {

          @Override
          public void actionPerformed(ActionEvent e) {
               // first find the index with highest score
               int highestIndex = 0;
               StudentClass objHighestStudent = arrStudentList.get(0);

               // go through the array
               for (int i = 0; i < arrStudentList.size(); i++) {

                    if (arrStudentList.get(i).getMarks() > arrStudentList.get(highestIndex).getMarks()) {
                         highestIndex = i;
                         objHighestStudent = arrStudentList.get(highestIndex);
                    }

               }

               ArrayList<StudentClass> arrHighest = new ArrayList<>();
               arrHighest.add(objHighestStudent);

               // display just the index
               ViewScreen objFrViewScreen = new ViewScreen(arrHighest);
               objFrViewScreen.setVisible(true);
               objFrViewScreen.setSize(450, 550);
               objFrViewScreen.setTitle("Highest Mark Student Screen By Chigbu CCI");
               objFrViewScreen.setResizable(false);

          }

     }

     private class mnuCountEvent implements ActionListener {

          @Override
          public void actionPerformed(ActionEvent e) {

               String subjectCode = JOptionPane.showInputDialog(rootPane, "Enter Subject Code:");

               int NoOfStudents = 0;

               for (StudentClass studentClass : arrStudentList) {

                    if (studentClass.getSubjectCode().equalsIgnoreCase(subjectCode)) {
                         NoOfStudents++;
                    }

               }

               JOptionPane.showMessageDialog(rootPane, "There are " + NoOfStudents + " Students offering course code; " + subjectCode, "INFO", JOptionPane.INFORMATION_MESSAGE);

          }

     }

     private class mnuExitEvent implements ActionListener {

          @Override
          public void actionPerformed(ActionEvent e) {
               System.exit(0);
          }

     }

     /**
      * @param args the command line arguments
      */
     public static void main(String[] args) {
          // TODO code application logic here
          // create object of this class
          MainScreenScreen frmMainScreenScreen = new MainScreenScreen();

          frmMainScreenScreen.setVisible(true);

          frmMainScreenScreen.setTitle("Main Menu Screen by Chigbu CCI");
          
          frmMainScreenScreen.setSize(700, 700);

     }

}
