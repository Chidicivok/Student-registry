// Chigbu CCI - 223515760
package vut.gui;

import javax.swing.*;
import java.util.ArrayList;
import vut.data.StudentClass;

public class ViewScreen extends JFrame {

     // create object for text area
     JTextArea taDisplay = new JTextArea();

     public ViewScreen(ArrayList<StudentClass> objArrStudent) {

          // prevent user editig the text area
          taDisplay.setEditable(false);
          
          // create panel 
          JPanel panDisplay = new JPanel();

          // panel layout to null
          panDisplay.setLayout(null);

          // affix the text area onto the panel
          panDisplay.add(taDisplay);

          // set size for the display text area
          taDisplay.setBounds(0, 0, 450, 550);

          // affix panel onto jframe
          setContentPane(panDisplay);

          // size jframe
          setSize(450, 550);
          
          // call view all method
          viewAll(objArrStudent);

     }

     public void viewAll(ArrayList<StudentClass> objArrStudent) {
          taDisplay.append("Student No\tStudentName\tGender\tSubject Code\tMarks\n");

          for (int i = 0; i < objArrStudent.size(); i++) {
               taDisplay.append(objArrStudent.get(i).toString());
          }

     }

//     public static void main(String[] args) {
//          ViewScreen obj = new ViewScreen();
//          obj.setVisible(true);
//     }
}
