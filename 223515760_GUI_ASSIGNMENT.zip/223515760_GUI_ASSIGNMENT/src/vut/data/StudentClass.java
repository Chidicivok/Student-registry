// chigbu CCI - 223515760
package vut.data;


public class StudentClass {
     
     private String studentNumber, studentName, gender, subjectCode;
     private int marks;

     public StudentClass(String studentNumber, String studentName, String gender, String subjectCode, int marks) {
          setStudentNumber(studentNumber);
          setStudentName(studentName);
          setGender(gender);
          setSubjectCode(subjectCode);
          setMarks(marks);
     }
     
     
     

     public String getStudentNumber() {
          return studentNumber;
     }

     public void setStudentNumber(String studentNumber) {
          
          if(studentNumber.isEmpty()) {
               throw new IllegalArgumentException("Enter student number");
          }
          
          if (studentNumber.length() != 9 ) {
               throw new IllegalArgumentException("Student number must be 9 characters long");
          }
          
          for (int i = 0; i < studentNumber.length(); i++) {
               if (    !Character.isDigit(studentNumber.charAt(i))) {
                    throw new IllegalArgumentException("Student number must be numerical digits");
               }
          }

          this.studentNumber = studentNumber;
     }

     public String getStudentName() {
          return studentName;
     }

     public void setStudentName(String studentName) {

          if(studentName.isEmpty()) {
               throw new IllegalArgumentException("Enter student's name");
          }
          
          if (studentName.length() < 2) {
               throw new IllegalArgumentException("Invalid name");
          }
          
          this.studentName = studentName;
     }

     public String getGender() {
          return gender;
     }

     public void setGender(String gender) {
          this.gender = gender;
     }

     public String getSubjectCode() {
          return subjectCode;
     }

     public void setSubjectCode(String subjectCode) {
          this.subjectCode = subjectCode;
     }

     public int getMarks() {
          return marks;
     }

     public void setMarks(int marks) {
          
          if (marks < 0 || marks > 100) {
               throw new IllegalArgumentException("Marks must be between 0 and 100");
          }
          this.marks = marks;
     }

     @Override
     public String toString() {
          return  studentNumber + "\t" + studentName + "\t" + gender + "\t" + subjectCode + "\t" + marks + "\n";
     }
     
     
     
     
     
}
